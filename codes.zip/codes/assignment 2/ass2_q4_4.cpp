#include<bits/stdc++.h>
using namespace std;
int main() {
	int arr[26]={};
	string str;
	cout<<"Enter the string you want to make in alphabetical order"<<endl;
	getline(cin,str);
	for(int i=0;i<str.length();i++){
		arr[str[i]-'a']++;
	}
	cout<<"Final result: "<<endl;
	for(int i=0;i<26;i++){
		if(arr[i]>0){
			
			while(arr[i]){
				char c=i+'a';
				cout<<c;
				arr[i]--;
			}
		}
		
	}
   return 0;
}
