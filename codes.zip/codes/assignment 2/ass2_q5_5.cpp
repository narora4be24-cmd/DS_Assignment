#include<iostream>
using namespace std;

int main() {
    int r, c;
    cout << "Enter rows: ";
    cin >> r;
    cout << "Enter cols: ";
    cin >> c;
    if (r != c) {
        cout << "Symmetric matrix must be square!" << endl;
        return 0;
    }
    int n = r;
    int s = (n * (n + 1)) / 2;   // only lower triangle needed
    int arr[s];
    cout << "Enter " << s << " elements (lower triangular part row-wise): " << endl;
    for (int i = 0; i < s; i++) {
        cin >> arr[i];
    }
    cout << "Resultant Symmetric Matrix is: " << endl;
    int k = 0; // index in arr[]
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i >= j) {
                cout << arr[k] << " ";  // lower triangle
                k++;
            } else {
                
                int index = (j * (j + 1)) / 2 + i;
                cout << arr[index] << " ";
            }
        }
        cout << endl;
    }

    return 0;
}
