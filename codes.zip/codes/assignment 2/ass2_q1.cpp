#include<bits/stdc++.h>
using namespace std;
    void display (int arr[] , int size){
    for (int i = 0; i<size ; i++){
        cout << arr[i]<<" ";         //displaying the array //
    }
    cout<<endl;
}
void binarysearch(int arr[], int size , int target){     // implementing the binary search //
    int s =0;
    int e = size -1 ;
    while(s<=e){
        int mid = s + (e-s)/2;
        if (arr[mid]== target){
            cout <<"the element is at index "<<mid <<endl;
            return;
        }else
        if(arr[mid]<target){
            s = mid +1 ;
        }
        else{
            e = mid -1 ;
        }
    }
    cout <<"element not found in array "<<endl;
}


int main (){
    cout <<"the array is "<<endl;
    int arr[7] = { 10, 11, 15 , 16 , 18 , 20 , 30};
    display ( arr , 7);
    cout <<"enter the target element "<<endl;
    int target ;
    cin >> target ;
     binarysearch( arr , 7 , target );
    return 0 ; 
}