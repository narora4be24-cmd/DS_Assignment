#include<bits/stdc++.h>
using namespace std;
    void display (int arr[] , int size){
    for (int i = 0; i<size ; i++){
        cout << arr[i]<<" ";                           //displaying the array //
    }
    cout<<endl;
}
 void bubblesort( int arr[], int size ){
    for (int i =0; i<size ; i++){
        for (int j =0 ; j<size -1 -i ; j++){
            if(arr[j]>arr[j+1]){
                swap(arr[j], arr[j+1]);
            }
        }
    }
 }

int main(){
    int arr[7]={64 , 34 , 25 , 12 , 22 , 11 , 90};
    cout <<"current array is "<<endl;
    display ( arr , 7);
    cout <<"after applying bubble sort "<<endl;
    bubblesort(arr , 7 );
    display ( arr , 7);

    return 0;
}