#include<bits/stdc++.h>
using namespace std;
    void display (int arr[] , int size){
    for (int i = 0; i<size ; i++){
        cout << arr[i]<<" ";   //displaying the array //
    }
    cout<<endl;
}

int missing(int arr[], int size){        //linear search //
    int sum =0;
    for(int i =0; i<size;i++){
        sum+=arr[i];
    }
    return sum ;
}

int binary(int arr[], int size ){    // implementing the binary search //
    int s =0;
    int e = size -1 ;
    int ans  =0;
    while(s<=e){
        int mid = s + (e-s)/2;
        if(arr[mid]==mid+1){
                s= mid +1;
        }else{
            ans=mid;
            e = mid -1;

        }
    }
    return ans+1 ;
    
}

int main(){
    cout <<"the array is "<<endl;
    int arr[7]={ 1, 2 , 3 ,4 , 6 , 7 , 8};    //sorted array //
    display(arr , 7);
    int answer = missing(arr , 7);
    int x = 8;             // value of n //
    int sum = x*(x+1)/2;      // sum of first n natural number//
    int final = sum - answer ;
    cout<<"the missing number in the array from range 1 to 8 by linear search  is " <<final <<endl;
    int binans= binary(arr , 7);
    cout<<"the missing number in the array from range 1 to 8 by binary search  is " <<binans <<endl;
    return 0;
}