#include<bits/stdc++.h>
using namespace std;
void removeduplicate(int arr[], int size , int& res){
    
    sort(arr,arr + size);
    int i= 1;
    while(i<size){
        if(arr[i]!=arr[res-1]){
            arr[res]=arr[i];
            res++;
        }
        i++;
    }
}
int main(){
    int array[9]={1,1,2,3,3,4,4,6,6};
    int res =1;
    removeduplicate(array , 9, res);

    for( int i =0; i<res; i++){
        cout <<array[i]<<" ";
    }
    return 0;
}