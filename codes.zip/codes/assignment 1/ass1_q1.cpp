#include<bits/stdc++.h>
using namespace std;

void userinput(int arr[], int size){
    for ( int i =0 ; i<size; i++){
        cout <<"enter the "<< i+1 << "  element "<<endl;                          // input from user //
            cin >> arr[i];
    }
}

void display(int arr[], int size ){
    int i =0;
    while ( i < size  ){                                           // displaying array//
        cout << arr[i]<<" "; 
        i++;
    }
    cout<<endl;
}

void insert(int arr[], int& size , int value , int index){
    size +=1;           // increasing size of array 

    for ( int i = size-1 ; i>= index ; i-- ){                                     // insertion in array //
        arr[i+1] = arr[i];
    }
    arr[index]= value ;
}

void remove(int arr[], int& size , int index){
   for ( int i = index ; i< size ; i++ ){                                     // DELETION in array //
        arr[i] = arr[i+1];
    }
    size -=1;
}

void  linearsearch(int arr[], int size , int value) {
    for (int i =0; i<size; i++){
        if(arr[i]==value){                                              // linear search//
            cout<<" element is present"<<endl;
            return;
        }
    }
    cout<<"element not present"<<endl;
}

int main(){
    int size = 0;
    int array[100];
    int choice;

    while(choice != 6){
        cout<<"\n---MENU---"<<endl;
        cout<<"1.CREATE"<<endl;
        cout<<"2.DISPLAY"<<endl;
        cout<<"3.INSERT"<<endl;
        cout<<"4.DELETE"<<endl;
        cout<<"5.LINEAR SEARCH"<<endl;
        cout<<"6.EXIT"<<endl;
        cout<<"Enter your choice: ";
        cin >> choice;

        if(choice == 1){
            cout<<"enter the number of elements in array"<<endl;
            cin >> size;                           // taking input from user//
            userinput ( array , size ) ;         
            display ( array , size ) ;
        }
        else if(choice == 2){
            display ( array , size ) ;
        }
        else if(choice == 3){
            cout <<"enter the value to be insterted "<< endl;
            int value ;
            cin >> value ;
            cout <<"enter the index to be insterted "<< endl;
            int indexval;
            cin>> indexval;
            insert ( array , size , value , indexval);             // insertion in array
            display ( array , size );
        }
        else if(choice == 4){
            cout <<"enter the index to be deleted "<< endl;
            int indexval;
            cin>> indexval;
            
            remove ( array , size ,   indexval);                  // deletion in array
            display ( array , size );
        }
        else if(choice == 5){
            cout <<"enter the value to be searched "<< endl;
            int value;
            cin>> value;
            linearsearch(array, size , value);                     //linear search//
        }
        
    }
    return 0;
}
