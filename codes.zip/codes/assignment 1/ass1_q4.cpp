#include<bits/stdc++.h>        
using namespace std;

void display (int arr[] , int size){
    for (int i = 0; i<size ; i++){
        cout << arr[i]<<" ";                           //displaying the array //
    }
    cout<<endl;
}

void reverse(int arr[], int size){
    int i =0;
    int j = size -1;
    while( i <= j){
        swap(arr[i], arr[j]);                                // temp = arr[i] , arr[i]= arr[j], arr[j]= temp //
        i++; 
        j--;
         
    }
}



int main(){
    cout <<"Array before reversing is "<< endl;
    int arr[7] = { 1, 2 , 3 , 4, 5 ,6 , 7};
    display(arr , 7);
    cout <<"Array after reversing is "<< endl;
    reverse(arr , 7);
    display(arr , 7);
    return 0;
}